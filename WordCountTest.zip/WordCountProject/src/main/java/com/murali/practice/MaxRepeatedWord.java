package com.murali.practice;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * This class used to read words from text file and count the no of occurrences
 * 
 * @author mkrishna
 *
 */
public class MaxRepeatedWord {

	/**
	 * This method reads the text file and counts and stores all the unique
	 * words and it occurrences in a map
	 * 
	 * @param fileName
	 * @return
	 */
	public static Map<String, Integer> buildWordMap(String fileName) {
		// Using Map to store the words and it occurrences.
		Map<String, Integer> wordMap = new HashMap<>();
		// Using try-with-resource statement for automatic resource management
		try (FileInputStream fis = new FileInputStream(fileName);
				DataInputStream dis = new DataInputStream(fis);
				BufferedReader br = new BufferedReader(new InputStreamReader(dis))) {
			// words are separated by whitespace
			Pattern pattern = Pattern.compile("\\s+");
			String line = null;
			while ((line = br.readLine()) != null) {
				// add this if case sensitivity is not required i.e. Java = java
				line = line.toLowerCase();
				String[] words = pattern.split(line);
				for (String word : words) {
					if (wordMap.containsKey(word)) {
						wordMap.put(word, (wordMap.get(word) + 1));
					} else {
						wordMap.put(word, 1);
					}
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return wordMap;
	}

	/**
	 * This method is used to sort in decreasing order the wordMap based on
	 * values
	 * 
	 * @param wordMap
	 * @return
	 */
	public static List<Entry<String, Integer>> sortByValueInDecreasingOrder(Map<String, Integer> wordMap) {
		Set<Entry<String, Integer>> entries = wordMap.entrySet();
		List<Entry<String, Integer>> list = new ArrayList<>(entries);
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
			@Override
			public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});
		return list;
	}

	/**
	 * This method returns word and word count for top nth word
	 * 
	 * @param fileName
	 * @param n
	 * @return
	 * @throws Exception
	 */
	public static Entry<String, Integer> getNthWordCount(String fileName, int n) throws Exception {
		Map<String, Integer> wordMap = buildWordMap(fileName);
		List<Entry<String, Integer>> list = sortByValueInDecreasingOrder(wordMap);
		if (n >= list.size()) {
			throw new Exception("No of unique words are " + list.size() + " which is less than " + n);
		}
		return list.get(n - 1);

	}

	public static void main(String args[]) {
		Map<String, Integer> wordMap = buildWordMap("sample.txt");
		List<Entry<String, Integer>> list = sortByValueInDecreasingOrder(wordMap);

		// case 1 print top 5 most used words
		for (int i = 0; i < 5; i++) {
			System.out.println(list.get(i).getKey() + " => " + list.get(i).getValue());
		}

		try {
			// case 2 print 3rd,9th words etc
			Entry<String, Integer> entry = getNthWordCount("sample.txt", 3);
			System.out.println("3rd most used word:: " + entry.getKey() + " => " + entry.getValue());

			Entry<String, Integer> entry1 = getNthWordCount("sample.txt", 9);
			System.out.println("9th most used word:: " + entry1.getKey() + " => " + entry1.getValue());

			// case 3 if n is greater than size of map;
			Entry<String, Integer> entry2 = getNthWordCount("sample.txt", 1000);
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

	}
}