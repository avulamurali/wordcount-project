package com.murali.practice;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;

public class MaxRepeatedWordTest {

	@Test
	public void testValidTopFiveWords() {
		Map<String, Integer> wordMap = MaxRepeatedWord.buildWordMap("sample.txt");
		List<Entry<String, Integer>> list = MaxRepeatedWord.sortByValueInDecreasingOrder(wordMap);
		// assert statements
		assertEquals("Top 1st word and its count", "hello:60", list.get(0).getKey() + ":" + list.get(0).getValue());
		assertEquals("Top 2rd word and its count", "the:23", list.get(1).getKey() + ":" + list.get(1).getValue());
		assertEquals("Top 3rd word and its count", "and:14", list.get(2).getKey() + ":" + list.get(2).getValue());
		assertEquals("Top 4rd word and its count", "to:12", list.get(3).getKey() + ":" + list.get(3).getValue());
		assertEquals("Top 5rd word and its count", "of:11", list.get(4).getKey() + ":" + list.get(4).getValue());
	}

	@Test
	public void testValidTopNthWord() throws Exception {
		// assert statements
		assertEquals("Top 1st word and its count", "and", MaxRepeatedWord.getNthWordCount("sample.txt", 3).getKey());
		assertEquals("Top 1st word and its count", "of", MaxRepeatedWord.getNthWordCount("sample.txt", 5).getKey());
		assertEquals("Top 1st word and its count", "north", MaxRepeatedWord.getNthWordCount("sample.txt", 9).getKey());
		assertEquals("Top 1st word and its count", "fried", MaxRepeatedWord.getNthWordCount("sample.txt", 18).getKey());
	}

	@Test(expected = Exception.class)
	public void testInvalidTopNthWord() throws Exception {
		Entry<String, Integer> entry = MaxRepeatedWord.getNthWordCount("sample.txt", 960);

	}
}
